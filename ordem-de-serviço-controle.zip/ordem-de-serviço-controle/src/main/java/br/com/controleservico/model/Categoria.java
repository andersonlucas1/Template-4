package br.com.controleservico.model;

public enum Categoria {

    URGENTE,
    NAOURGENTE,
    OUTRAS
}
